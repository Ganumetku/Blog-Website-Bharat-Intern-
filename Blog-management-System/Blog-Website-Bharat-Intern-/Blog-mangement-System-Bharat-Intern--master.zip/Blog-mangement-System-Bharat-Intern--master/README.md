﻿# Blog_management_Website

 
->Virtual Internship at **Bharat Intern** in Full Stack Development

->Task 1 is about the Content Management Tool

->Web Technologies used: Html, CSS, JavaScript ,ExpressJS , EJS, MongoDB, NodeJS

->This repository contains the code for a Blog Management System Website, which allows users to create and manage blog posts. The website provides an intuitive interface 
  for users to add text, images, and other elements required for creating engaging blog content
